import { createSlice,createSelector,createAsyncThunk,} from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
const CONFIG_OBJ={
    headers:{
      "Content-Type":"application/json",
      "Authorization":"Bearer "+localStorage.getItem("token")
    }
  }


  export const addUser = createAsyncThunk(
    "users/adduser", async (user, thunkAPI) => {  
       try {
       
          const response = await axios.get(`http://localhost:3300/user/${user.id}`,CONFIG_OBJ);
          console.log(response.data.user)
          debugger
          return await response.data.user;

        } catch (error) {
           return thunkAPI.rejectWithValue({ error: error.message });
        }
  });



  const userSlice = createSlice({
   
    name: "user",
    initialState: {
       user: {},
    },
    reducers: {},
    extraReducers: (builder) => {
       builder.addCase(addUser.pending, (state) => {
         state.user = [];
       });
       builder.addCase(
         addUser.fulfilled, (state, { payload }) => {
             state.user.push(payload);
       });
       builder.addCase(addUser.rejected,(state, action) => {
         
         toast.error("user not added to store please relogin")
         
       });
     }
 });
 
 
 export const selectUsers = createSelector(
   (state) => ({
      user: state.user
   }), (state)=>state)

export default userSlice.reducer
