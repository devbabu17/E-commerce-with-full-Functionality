import "./Home.css"
// importing Header Footer Homecover and Slider components
// import Header from "./components/Header"
// import Footer from "./components/Footer"
import Homecover from "./pages/Homecover"
import Slider from "./pages/Slider"
const Home = () => {
  return (
    <>
        
        <Homecover/>
        <Slider/>
        
    </>
  )
}

export default Home