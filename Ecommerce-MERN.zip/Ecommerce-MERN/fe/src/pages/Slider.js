import React from 'react'
import './Homecover.css'
// Slider component
const Slider = () => {
  return (
   <>
     <div className="container-fluid">
        <div id="carouselExample" className="carousel carousel-dark slide car-box">
          <div className="carousel-inner" style={{ backgroundColor: 'rgb(243, 221, 192)', margin: '15px 0' }}>
            <h2>Featured Products</h2>
            <div className="carousel-item active">
              <div className="cards-wrapper">
                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/dress/h/e/n/xl-vika-f129-f137-sumertex-original-imagtg7uravvcgzf.jpeg?q=70" className="card-img-top" alt="womendress" />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Red Dress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/832/832/xif0q/jean/p/s/a/32-sc-001-pgmj-025-podge-original-imaghhvggwmg3tes.jpeg?q=70&crop=false" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Jeans</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/skirt/z/a/d/m-1-p-popm11306-metronaut-original-imagv2t4gccsfnxk.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Skirt</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/kvtuxe80/kids-dress/p/m/9/13-14-years-gown-005-yellow-ajiza-garments-original-imag8mhwvbzxxegp.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Princess Dress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>
              </div>
            </div>

            <div className="carousel-item">
              <div className="cards-wrapper">
                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/dress/y/v/1/l-vrro-29-drs-bodycon-dress-frock-style-dress-party-wear-dress-original-imagaf9bwxgjdrnt-bb.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Dress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/dress/y/m/7/l-women-s-ruched-bodycon-mini-dress-summer-spaghetti-strap-party-original-imagyfjy8nrbuhkp.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">womendress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/dress/s/e/p/s-gwdmswt1098-growish-original-imagzmr45fu4xkvv.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Skirt</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/kjym9ow0/dress/y/b/s/s-dr850yl-berrylush-original-imafzezpdza2akrx.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Princess Dress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>
              </div>
            </div>

            <div className="carousel-item">
              <div className="cards-wrapper">
                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/j5h264w0/dress/t/d/g/m-la2353-orange-sera-original-imaew5suhcbdnyzq.jpeg?q=70" className="card-img-top" alt="..." />
                 </div>
                  <div className="card-body">
                    <h5 className="card-title">Skirt</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/3/j/v/xxl-st10-vebnor-original-imagnvrqgv7e5crg.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Princess Dress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/u/f/4/m-dpwhite-woxen-original-imagxazzudcr6adz.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Red Dress</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>

                <div className="card">
                  <div className="image-wrapper">
                    <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/r/9/n/xxl-patta-14-jai-textiles-original-imagn2fzpawqukgq.jpeg?q=70" className="card-img-top" alt="..." />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">Jeans</h5>
                    <h5>$15</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href='/' className="btn btn-warning btn-hover"><i className="fa-solid fa-cart-shopping"></i> Add to Cart</a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
   </>
  )
}

export default Slider