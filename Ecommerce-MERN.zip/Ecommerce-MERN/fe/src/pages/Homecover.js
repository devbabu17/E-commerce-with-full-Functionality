import React from 'react';
import './Homecover.css'

// centered opicture below header Brand amd slogan of our company
const Homecover = () => {
  return (
    <>
      <div className="row caro">
        <div className="col-12 back-img">
          <p className="log">Ecommerce</p>
          <p className="smry">Cloths that talk on behalf of you. Something for every occasion.</p>
        </div>
      </div>
    </>
  );
};

export default Homecover;
